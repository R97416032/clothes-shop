<template>
  <router-view>
	  <div id="routerpage">
	  	<!-- <router-link ></router-link> -->
	  	
	  </div>
  </router-view>
</template>

<script>
	// export default {
	// 	mounted() {
	// 		this.$router.push("/order")
	// 	}
	// }
</script>

<style>
	
</style>
